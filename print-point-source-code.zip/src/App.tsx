import React, { useState, useEffect } from 'react';
import { 
  Order, 
  ServiceItem, 
  PriceTableItem, 
  ShopConfig, 
  Coupon, 
  OrderStatus 
} from './types';
import { 
  DEFAULT_SHOP_CONFIG, 
  DEFAULT_SERVICES, 
  DEFAULT_PRICE_ITEMS, 
  DEFAULT_COUPONS, 
  INITIAL_ORDERS 
} from './data/defaultData';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { QuickActionSection } from './components/QuickActionSection';
import { ServicesGrid } from './components/ServicesGrid';
import { PriceCalculator } from './components/PriceCalculator';
import { PriceListTable } from './components/PriceListTable';
import { SpecialOffers } from './components/SpecialOffers';
import { OrderTracking } from './components/OrderTracking';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { OrderModal } from './components/OrderModal';
import { OwnerAdminModal } from './components/OwnerAdminModal';
import { OwnerShareModal } from './components/OwnerShareModal';
import { PrintableReceipt } from './components/PrintableReceipt';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { 
  Sparkles, 
  Megaphone, 
  CheckCircle2, 
  Crown, 
  Edit3, 
  Package, 
  Share2, 
  LogOut,
  ExternalLink 
} from 'lucide-react';

export default function App() {
  // 1. Persistent Shop Configuration
  const [shopConfig, setShopConfig] = useState<ShopConfig>(() => {
    const saved = localStorage.getItem('print_point_config');
    if (saved) {
      try { 
        const parsed = JSON.parse(saved);
        // Ensure new photo & discount fields are populated if missing in old cache
        return { ...DEFAULT_SHOP_CONFIG, ...parsed };
      } catch (e) { }
    }
    return DEFAULT_SHOP_CONFIG;
  });

  // 2. Persistent Services List
  const [services, setServices] = useState<ServiceItem[]>(() => {
    const saved = localStorage.getItem('print_point_services');
    if (saved) {
      try { 
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length >= 10) return parsed;
      } catch (e) { }
    }
    return DEFAULT_SERVICES;
  });

  // 3. Persistent Price Table Items
  const [priceItems, setPriceItems] = useState<PriceTableItem[]>(() => {
    const saved = localStorage.getItem('print_point_prices');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { }
    }
    return DEFAULT_PRICE_ITEMS;
  });

  // 4. Persistent Coupons
  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    const saved = localStorage.getItem('print_point_coupons');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { }
    }
    return DEFAULT_COUPONS;
  });

  // 5. Persistent Customer Orders
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('print_point_orders');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { }
    }
    return INITIAL_ORDERS;
  });

  // 6. Owner Session
  const [isOwnerMode, setIsOwnerMode] = useState<boolean>(() => {
    return localStorage.getItem('print_point_owner_auth') === 'true';
  });

  // UI State
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [orderModalOpen, setOrderModalOpen] = useState<boolean>(false);
  const [adminModalOpen, setAdminModalOpen] = useState<boolean>(false);
  const [adminActiveTab, setAdminActiveTab] = useState<string>('orders');
  const [shareModalOpen, setShareModalOpen] = useState<boolean>(false);
  const [prefillOrder, setPrefillOrder] = useState<{
    serviceName: string;
    qty?: string;
    estimatedPrice?: number;
    notes?: string;
    urgent?: boolean;
    coupon?: string;
  } | null>(null);

  const [activePrintOrder, setActivePrintOrder] = useState<Order | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('print_point_config', JSON.stringify(shopConfig));
  }, [shopConfig]);

  useEffect(() => {
    localStorage.setItem('print_point_services', JSON.stringify(services));
  }, [services]);

  useEffect(() => {
    localStorage.setItem('print_point_prices', JSON.stringify(priceItems));
  }, [priceItems]);

  useEffect(() => {
    localStorage.setItem('print_point_coupons', JSON.stringify(coupons));
  }, [coupons]);

  useEffect(() => {
    localStorage.setItem('print_point_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('print_point_owner_auth', isOwnerMode ? 'true' : 'false');
  }, [isOwnerMode]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Handlers
  const handleOpenOrderModal = (serviceName?: string, extraData?: any) => {
    if (serviceName) {
      setPrefillOrder({
        serviceName,
        ...extraData
      });
    } else {
      setPrefillOrder(null);
    }
    setOrderModalOpen(true);
  };

  const handleOpenAdminWithTab = (tab: string = 'orders') => {
    setAdminActiveTab(tab);
    setAdminModalOpen(true);
  };

  const handleOrderCreated = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);
    showToast(`অর্ডার #${newOrder.id} তৈরি হয়েছে! WhatsApp ওপেন হচ্ছে...`);
  };

  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status } : o))
    );
    showToast(`অর্ডার #${orderId} এর স্ট্যাটাস "${status}" করা হয়েছে`);
  };

  const handleUpdatePaymentStatus = (orderId: string, paymentStatus: Order['paymentStatus']) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, paymentStatus } : o))
    );
    showToast(`অর্ডার #${orderId} পেমেন্ট স্ট্যাটাস "${paymentStatus}" হয়েছে`);
  };

  const handleDeleteOrder = (orderId: string) => {
    setOrders((prev) => prev.filter((o) => o.id !== orderId));
    showToast(`অর্ডার #${orderId} মুছে ফেলা হয়েছে`);
  };

  const handlePrintOrder = (order: Order) => {
    setActivePrintOrder(order);
    setTimeout(() => {
      window.print();
    }, 300);
  };

  // Quick price update from anywhere (service card or admin)
  const handleQuickUpdatePrice = (serviceId: string, newPrice: number) => {
    setServices((prev) =>
      prev.map((s) => (s.id === serviceId ? { ...s, startingPrice: newPrice } : s))
    );
    showToast(`মূল্য পরিবর্তিত হয়ে ৳${newPrice} হয়েছে!`);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col font-sans text-slate-800">
      
      {/* Printable Receipt (Invisible except on print) */}
      <PrintableReceipt order={activePrintOrder} shopConfig={shopConfig} />

      {/* 👑 PERSISTENT OWNER TOP BAR (Shows when Owner is authenticated) */}
      {isOwnerMode && (
        <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 text-slate-950 px-4 py-2 text-xs font-black flex flex-wrap items-center justify-between gap-2 shadow-md border-b border-amber-600/40 sticky top-0 z-50">
          <div className="flex items-center gap-2">
            <span className="p-1 bg-black/20 rounded-md">
              <Crown className="w-4 h-4 text-white" />
            </span>
            <span className="tracking-tight text-white drop-shadow-sm">
              ওনার কন্ট্রোল মোড সচল ({shopConfig.shopName}) | পরিচালক: {shopConfig.ownerName}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => handleOpenAdminWithTab('site-content')}
              className="bg-white/95 hover:bg-white text-slate-900 px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 shadow-sm transition active:scale-95 cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5 text-blue-700" />
              <span>সাইট এডিট</span>
            </button>

            <button
              onClick={() => handleOpenAdminWithTab('services')}
              className="bg-white/95 hover:bg-white text-slate-900 px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 shadow-sm transition active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>মূল্য ও সেবা এডিট</span>
            </button>

            <button
              onClick={() => handleOpenAdminWithTab('coupons')}
              className="bg-white/95 hover:bg-white text-slate-900 px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 shadow-sm transition active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-rose-600" />
              <span>ডিসকাউন্ট ছাড়ুন</span>
            </button>

            <button
              onClick={() => handleOpenAdminWithTab('orders')}
              className="bg-white/95 hover:bg-white text-slate-900 px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 shadow-sm transition active:scale-95 cursor-pointer"
            >
              <Package className="w-3.5 h-3.5 text-rose-600" />
              <span>অর্ডারসমূহ ({orders.length})</span>
            </button>

            <button
              onClick={() => setShareModalOpen(true)}
              className="bg-black/30 hover:bg-black/50 text-white px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>ওয়েবসাইট লিংক</span>
            </button>

            <button
              onClick={() => {
                setIsOwnerMode(false);
                showToast('ওনার মোড থেকে লগআউট করা হয়েছে');
              }}
              className="text-white hover:text-black font-bold px-2 py-1 rounded transition flex items-center gap-1 cursor-pointer"
              title="ওনার মোড বন্ধ করুন"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>লগআউট</span>
            </button>
          </div>
        </div>
      )}

      {/* Notice Banner */}
      {shopConfig.noticeBanner && (
        <div className="bg-amber-400 text-[#031B4E] text-xs font-bold py-1.5 px-4 text-center border-b border-amber-500/40 flex items-center justify-center gap-2">
          <Megaphone className="w-3.5 h-3.5 shrink-0" />
          <span>{shopConfig.noticeBanner}</span>
        </div>
      )}

      {/* Header with PrintPointLogo & Navigation */}
      <Header
        shopConfig={shopConfig}
        onOpenOrderModal={handleOpenOrderModal}
        onOpenAdminModal={() => handleOpenAdminWithTab('orders')}
        onOpenShareModal={() => setShareModalOpen(true)}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      {/* Main Content */}
      <main className="flex-grow">
        {/* 1. Hero Banner with Owner's Real Photo & Reference Mockup styling */}
        <Hero
          shopConfig={shopConfig}
          onOpenOrderModal={handleOpenOrderModal}
          isOwnerMode={isOwnerMode}
          onOpenAdminModal={handleOpenAdminWithTab}
        />

        {/* 2. Grid of 14 Service Cards + Big Red Order Button (exact matching) */}
        <ServicesGrid
          services={services}
          onSelectService={(serviceName) => handleOpenOrderModal(serviceName)}
          searchQuery={searchQuery}
          isOwnerMode={isOwnerMode}
          onQuickUpdatePrice={handleQuickUpdatePrice}
        />

        {/* 3. Trust Bar & 4 Quick-Action Cards matching bottom of banner */}
        <QuickActionSection
          shopConfig={shopConfig}
          onOpenOrderModal={handleOpenOrderModal}
          orders={orders}
          onTrackOrder={(orderId) => {
            const inputEl = document.getElementById('trackInput') as HTMLInputElement;
            if (inputEl) inputEl.value = orderId;
          }}
        />

        {/* 4. Interactive Cost Calculator */}
        <PriceCalculator
          onProceedToOrder={(prefillData) => {
            setPrefillOrder({
              serviceName: prefillData.serviceName,
              qty: prefillData.qty,
              estimatedPrice: prefillData.estimatedPrice,
              notes: prefillData.notes,
              urgent: prefillData.urgent
            });
            setOrderModalOpen(true);
          }}
        />

        {/* 5. Full Transparent Price Table */}
        <PriceListTable
          priceItems={priceItems}
          onOrderService={(serviceName) => handleOpenOrderModal(serviceName)}
        />

        {/* 6. Special Promo Offers & Coupons */}
        <SpecialOffers
          coupons={coupons}
          onClaimOffer={(couponCode) => {
            setPrefillOrder({
              serviceName: '২০% ডিসকাউন্ট স্পেশাল অফার',
              coupon: couponCode,
              notes: `কুপন কোড: ${couponCode}`
            });
            setOrderModalOpen(true);
          }}
        />

        {/* 7. Live Order Tracking */}
        <OrderTracking
          orders={orders}
          shopConfig={shopConfig}
        />

        {/* 8. Contact & Map Directions */}
        <ContactSection
          shopConfig={shopConfig}
        />
      </main>

      {/* Footer matching reference design */}
      <Footer
        shopConfig={shopConfig}
        onOpenAdminModal={() => handleOpenAdminWithTab('orders')}
        onOpenShareModal={() => setShareModalOpen(true)}
      />

      {/* Floating WhatsApp Quick Chat Button */}
      <FloatingWhatsApp
        shopConfig={shopConfig}
        onOpenOrderModal={() => handleOpenOrderModal()}
      />

      {/* Modals */}
      <OrderModal
        isOpen={orderModalOpen}
        onClose={() => setOrderModalOpen(false)}
        services={services}
        shopConfig={shopConfig}
        coupons={coupons}
        prefill={prefillOrder}
        onOrderCreated={handleOrderCreated}
      />

      <OwnerAdminModal
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
        orders={orders}
        onUpdateOrderStatus={handleUpdateOrderStatus}
        onUpdatePaymentStatus={handleUpdatePaymentStatus}
        onDeleteOrder={handleDeleteOrder}
        shopConfig={shopConfig}
        onUpdateShopConfig={(newConf) => {
          setShopConfig(newConf);
          showToast('দোকানের সেটিংস ও সাইটের লেখা সংরক্ষিত হয়েছে');
        }}
        services={services}
        onUpdateServices={(newSrv) => {
          setServices(newSrv);
          showToast('সেবাসমূহ আপডেট করা হয়েছে');
        }}
        priceItems={priceItems}
        onUpdatePriceItems={(newItems) => {
          setPriceItems(newItems);
          showToast('মূল্য তালিকা আপডেট হয়েছে');
        }}
        coupons={coupons}
        onUpdateCoupons={(newCoupons) => {
          setCoupons(newCoupons);
          showToast('কুপন ও অফার আপডেট হয়েছে');
        }}
        onPrintOrder={handlePrintOrder}
        isOwnerMode={isOwnerMode}
        setIsOwnerMode={setIsOwnerMode}
        initialTab={adminActiveTab}
      />

      <OwnerShareModal
        isOpen={shareModalOpen}
        onClose={() => setShareModalOpen(false)}
        shopConfig={shopConfig}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-6 z-50 bg-[#031B4E] text-white px-4 py-3 rounded-2xl shadow-2xl border border-amber-400 flex items-center gap-2.5 text-xs font-bold animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
}
