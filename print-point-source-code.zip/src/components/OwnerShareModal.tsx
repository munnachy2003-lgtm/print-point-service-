import React, { useState } from 'react';
import { 
  X, 
  Copy, 
  Check, 
  ExternalLink, 
  QrCode, 
  Share2, 
  Smartphone, 
  Globe, 
  ShieldCheck,
  Printer,
  Sparkles,
  Zap
} from 'lucide-react';
import { ShopConfig } from '../types';

interface OwnerShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  shopConfig: ShopConfig;
}

export const OwnerShareModal: React.FC<OwnerShareModalProps> = ({ isOpen, onClose, shopConfig }) => {
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  if (!isOpen) return null;

  // The live direct application URLs
  const devUrl = 'https://ais-dev-el6be644rmjnza7zg43qzi-995710624182.asia-east1.run.app';
  const sharedUrl = 'https://ais-pre-el6be644rmjnza7zg43qzi-995710624182.asia-east1.run.app';
  const qrCodeApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(devUrl)}`;

  const handleCopy = (url: string, label: string) => {
    navigator.clipboard.writeText(url);
    setCopiedLink(label);
    setTimeout(() => setCopiedLink(null), 2500);
  };

  return (
    <div className="fixed inset-0 bg-black/65 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative max-h-[92vh] overflow-y-auto border border-slate-200">
        
        {/* Close Button */}
        <button 
          onClick={onClose} 
          className="absolute right-4 top-4 p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center space-y-3">
          <div className="w-14 h-14 bg-blue-50 text-[#031B4E] rounded-2xl flex items-center justify-center mx-auto shadow-sm border border-blue-200">
            <Share2 className="w-7 h-7 text-[#0F4C81]" />
          </div>

          <div>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              সরাসরি অনলাইনে ব্যবহারের লিংক
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-[#031B4E] mt-2">
              যেকোনো ব্রাউজারে ওপেন করার লাইভ লিংক
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              এই লিংকটি ব্যবহার করে আপনি বা আপনার যেকোনো গ্রাহক কম্পিউটার অথবা মোবাইল থেকে সরাসরি ওয়েবসাইটটি ব্যবহার করতে পারবেন।
            </p>
          </div>
        </div>

        {/* Links Box */}
        <div className="mt-5 space-y-4">
          
          {/* PRIMARY LIVE LINK */}
          <div className="bg-emerald-50/70 p-4 rounded-2xl border-2 border-emerald-400 space-y-2 shadow-sm">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-emerald-600 fill-emerald-600" />
                সরাসরি লাইভ অনলাইন লিংক (১০০% সচল)
              </span>
              <span className="text-[10px] bg-emerald-600 text-white px-2 py-0.5 rounded-full font-bold">
                অনলাইন লাইভ
              </span>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={devUrl}
                className="w-full bg-white border border-emerald-300 rounded-xl px-3 py-2 text-xs font-mono text-slate-800 outline-none select-all"
              />
              <button
                onClick={() => handleCopy(devUrl, 'dev')}
                className="bg-emerald-600 hover:bg-emerald-700 text-white p-2.5 rounded-xl transition shrink-0 cursor-pointer"
                title="কপি করুন"
              >
                {copiedLink === 'dev' ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
              </button>
              <a
                href={devUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#031B4E] hover:bg-[#0F4C81] text-white p-2.5 rounded-xl transition shrink-0 cursor-pointer"
                title="ব্রাউজারে নতুন ট্যাবে খুলুন"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>

            <p className="text-[11px] text-emerald-800 font-semibold">
              ✓ Google Chrome, Safari, Firefox, Edge, Opera সহ যেকোনো স্মার্টফোনে সরাসরি চলবে।
            </p>
          </div>

          {/* SECONDARY SHARED CLOUD RUN LINK */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-700 flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-blue-600" />
                শেয়ার্ড প্রিভিউ ক্লাউড রান লিংক
              </span>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={sharedUrl}
                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono text-slate-800 outline-none select-all"
              />
              <button
                onClick={() => handleCopy(sharedUrl, 'shared')}
                className="bg-slate-700 hover:bg-slate-900 text-white p-2.5 rounded-xl transition shrink-0 cursor-pointer"
                title="কপি করুন"
              >
                {copiedLink === 'shared' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
              <a
                href={sharedUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-slate-200 hover:bg-slate-300 text-slate-800 p-2.5 rounded-xl transition shrink-0 cursor-pointer"
                title="ব্রাউজারে খুলুন"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* QR Code For Shop Counter */}
          <div className="bg-gradient-to-br from-amber-50 to-orange-50/40 p-5 rounded-2xl border border-amber-200 text-center space-y-3">
            <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-amber-900">
              <QrCode className="w-4 h-4 text-amber-700" />
              <span>দোকানের কাউন্টারে টানানোর জন্য QR কোড</span>
            </div>

            <div className="bg-white p-3 rounded-2xl border border-amber-200 inline-block shadow-sm">
              <img
                src={qrCodeApiUrl}
                alt="Print Point QR Code"
                className="w-40 h-40 object-contain mx-auto"
                loading="lazy"
              />
              <p className="text-[10px] text-slate-500 font-bold mt-1">ক্যামেরা দিয়ে স্ক্যান করলেই সাইট খুলবে</p>
            </div>

            <p className="text-xs text-amber-800 max-w-xs mx-auto">
              দোকানে আসা গ্রাহকরা স্মার্টফোনের ক্যামেরা দিয়ে স্ক্যান করলেই সরাসরি প্রিন্ট পয়েন্ট পোর্টালে ঢুকে অর্ডার করতে পারবে!
            </p>

            <a
              href={qrCodeApiUrl}
              download="print_point_qr_code.png"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold px-4 py-2 rounded-xl text-xs transition shadow-sm"
            >
              <span>কিউআর কোড ডাউনলোড করুন</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

        </div>

        <div className="mt-5 text-center">
          <button
            onClick={onClose}
            className="w-full bg-[#031B4E] hover:bg-[#0F4C81] text-white font-bold py-2.5 rounded-xl text-xs transition cursor-pointer"
          >
            ঠিক আছে, বন্ধ করুন
          </button>
        </div>

      </div>
    </div>
  );
};
