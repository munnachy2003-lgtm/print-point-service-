import React from 'react';
import { 
  CheckCircle2, 
  MapPin, 
  Printer, 
  Zap, 
  ShieldCheck, 
  Sparkles, 
  ArrowRight, 
  ShoppingCart, 
  MessageCircle, 
  Tag, 
  Edit3,
  Percent
} from 'lucide-react';
import { ShopConfig } from '../types';

interface HeroProps {
  shopConfig: ShopConfig;
  onOpenOrderModal: (serviceName?: string) => void;
  isOwnerMode?: boolean;
  onOpenAdminModal?: (tab?: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ 
  shopConfig, 
  onOpenOrderModal, 
  isOwnerMode, 
  onOpenAdminModal 
}) => {
  return (
    <section className="relative bg-gradient-to-r from-[#031B4E] via-[#0A2E6E] to-[#0F4C81] text-white overflow-hidden py-8 sm:py-12 border-b-4 border-rose-600 shadow-xl">
      {/* Background Graphic elements & decorative curves */}
      <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px]"></div>
      
      {/* Curved decorative swooshes matching mockup */}
      <div className="absolute -left-20 top-0 w-96 h-96 bg-red-600/20 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -right-20 bottom-0 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl pointer-events-none"></div>

      {isOwnerMode && (
        <div className="max-w-7xl mx-auto px-4 sm:px-8 mb-4 relative z-20">
          <div className="bg-amber-400/20 border border-amber-400/70 backdrop-blur-md rounded-2xl p-2.5 sm:p-3 flex items-center justify-between text-xs text-amber-200">
            <span className="flex items-center gap-2 font-bold text-amber-300">
              <Edit3 className="w-4 h-4" />
              <span>ওনার মোড সচল: ছবি ও টেক্সট পরিবর্তন করতে চান?</span>
            </span>
            <button
              onClick={() => onOpenAdminModal && onOpenAdminModal('site-content')}
              className="bg-amber-400 hover:bg-amber-300 text-[#031B4E] font-black px-3 py-1 rounded-lg text-xs transition cursor-pointer"
            >
              হিরো টেক্সট এডিট
            </button>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center">
          
          {/* 1. LEFT: OWNER PHOTO (High Resolution, exactly as provided!) */}
          <div className="lg:col-span-3 flex flex-col items-center justify-center">
            <div className="relative group">
              {/* Outer Glowing Rings */}
              <div className="absolute -inset-1.5 bg-gradient-to-r from-amber-400 via-rose-500 to-blue-500 rounded-3xl blur-md opacity-75 group-hover:opacity-100 transition duration-500 animate-pulse"></div>
              
              {/* Image Frame */}
              <div className="relative w-48 sm:w-56 lg:w-60 h-64 sm:h-72 lg:h-80 rounded-2xl overflow-hidden border-4 border-white/90 shadow-2xl bg-slate-900">
                <img 
                  src={shopConfig.ownerPhoto || '/assets/aistudio/WhatsApp_Image_2026-11-02_at_2.51.14_PM_de0e69d2.jpeg'} 
                  alt={shopConfig.ownerName || 'Print Point Owner'} 
                  className="w-full h-full object-cover object-top transition duration-500 group-hover:scale-105"
                  onError={(e) => {
                    // Fallback if local asset path differs
                    (e.target as HTMLImageElement).src = '/assets/aistudio/WhatsApp_Image_2026-11-02_at_2.51.14_PM_de0e69d2.jpeg';
                  }}
                />

                {/* Director Badge at bottom of image */}
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent p-2.5 text-center">
                  <span className="text-[10px] text-amber-300 font-bold uppercase tracking-wider block">পরিচালক / ওনার</span>
                  <span className="text-xs sm:text-sm font-black text-white">{shopConfig.ownerName || 'মুন্না চৌধুরী'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* 2. CENTER: HERO TITLE & BANGAL TEXT */}
          <div className="lg:col-span-6 text-center lg:text-left space-y-4">
            
            {/* Big Brand Callout */}
            <div>
              <h1 className="text-4xl sm:text-6xl font-black text-amber-400 tracking-tight leading-tight drop-shadow-[0_4px_8px_rgba(0,0,0,0.6)]">
                প্রিন্ট পয়েন্ট
              </h1>
              
              <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-white mt-1 leading-snug drop-shadow-sm">
                আপনার সকল ডিজিটাল সেবা এখন অনলাইনে!
              </h2>

              <p className="text-xs sm:text-sm text-blue-100 mt-2 font-medium leading-relaxed max-w-xl">
                ঘরে বসেই অর্ডার করুন, ফাইল পাঠান, পেমেন্ট করুন, কাজ বুঝে নিন।
              </p>
            </div>

            {/* 3 Badges: দ্রুত সেবা, নির্ভরযোগ্য, সাশ্রয়ী মূল্য */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2.5 pt-1">
              <span className="bg-emerald-600/90 text-white text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-sm border border-emerald-400/40">
                <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                <span>দ্রুত সেবা</span>
              </span>

              <span className="bg-blue-600/90 text-white text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-sm border border-blue-400/40">
                <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                <span>নির্ভরযোগ্য</span>
              </span>

              <span className="bg-rose-600/90 text-white text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-sm border border-rose-400/40">
                <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                <span>সাশ্রয়ী মূল্য</span>
              </span>
            </div>

            {/* Location Line */}
            <div className="flex items-center justify-center lg:justify-start gap-2 text-xs text-amber-300 font-bold pt-1">
              <MapPin className="w-4 h-4 text-rose-500 fill-rose-500 shrink-0" />
              <span>{shopConfig.address}</span>
            </div>

            {/* Action buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-2">
              <button 
                onClick={() => onOpenOrderModal('সাধারণ অনলাইন সার্ভিস')} 
                className="bg-rose-600 hover:bg-rose-700 text-white font-black px-6 py-3 rounded-2xl shadow-xl transition transform hover:scale-105 active:scale-95 flex items-center gap-2 text-xs sm:text-sm cursor-pointer"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>এখনই অর্ডার করুন</span>
              </button>

              <a 
                href={`https://wa.me/${shopConfig.whatsapp}`} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-3 rounded-2xl transition flex items-center gap-2 text-xs sm:text-sm shadow-lg shadow-emerald-950/20"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp চ্যাট</span>
              </a>
            </div>

          </div>

          {/* 3. RIGHT: PRINTER & SPECIAL DISCOUNT STAMP */}
          <div className="lg:col-span-3 flex flex-col items-center justify-center relative">
            
            {/* Red Circular Special Offer Badge (Stamp) */}
            <div className="bg-gradient-to-br from-rose-600 to-red-700 text-white p-4 sm:p-5 rounded-3xl shadow-2xl border-4 border-white/80 text-center transform -rotate-3 hover:rotate-0 transition duration-300 relative overflow-hidden max-w-[220px]">
              <div className="absolute -right-4 -bottom-4 text-white/10">
                <Percent className="w-24 h-24" />
              </div>

              <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider inline-block mb-1">
                বিশেষ অফার!
              </span>

              <h3 className="text-base sm:text-lg font-black leading-tight">
                সকল সেবায় থাকছে আকর্ষণীয় ডিসকাউন্ট
              </h3>

              <div className="text-3xl sm:text-4xl font-black text-amber-300 my-1">
                {shopConfig.globalDiscountPercent || 20}%
              </div>

              <p className="text-[10px] text-red-100 font-semibold">
                ঘরে বসেই যে কোনো সেবায় ক্যাশব্যাক ও ছাড় উপভোগ করুন!
              </p>
            </div>

            {/* Printer Visual Illustration */}
            <div className="mt-4 flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/20 text-xs font-bold text-blue-200">
              <Printer className="w-4 h-4 text-amber-400" />
              <span>হাই-স্পিড ডিজিটাল ল্যাব প্রিন্টার</span>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
