import React, { useState } from 'react';
import { 
  MapPin, 
  Phone, 
  MessageCircle, 
  Mail, 
  Clock, 
  Send, 
  CheckCircle2, 
  Building2, 
  Navigation
} from 'lucide-react';
import { ShopConfig } from '../types';

interface ContactSectionProps {
  shopConfig: ShopConfig;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ shopConfig }) => {
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryPhone, setInquiryPhone] = useState('');
  const [inquiryMsg, setInquiryMsg] = useState('');
  const [sentSuccess, setSentSuccess] = useState(false);

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryName.trim() || !inquiryMsg.trim()) return;

    const waText = 
`*প্রিন্ট পয়েন্ট ওয়েবসাইট ইনকোয়ারি*
--------------------------------
👤 নাম: ${inquiryName}
📞 ফোন: ${inquiryPhone || 'দেওয়া হয়নি'}
💬 বার্তা: ${inquiryMsg}
--------------------------------`;

    const encoded = encodeURIComponent(waText);
    const waUrl = `https://wa.me/${shopConfig.whatsapp}?text=${encoded}`;
    window.open(waUrl, '_blank');

    setSentSuccess(true);
    setInquiryName('');
    setInquiryPhone('');
    setInquiryMsg('');
    setTimeout(() => setSentSuccess(false), 4000);
  };

  return (
    <section id="contact" className="max-w-7xl mx-auto px-4 sm:px-8 py-16 scroll-mt-16">
      
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-[#0F4C81] font-bold text-xs uppercase tracking-widest bg-blue-50 px-3.5 py-1.5 rounded-full border border-blue-200">
          যোগাযোগ ও লোকেশন
        </span>
        <h2 className="text-2xl sm:text-4xl font-black text-[#031B4E] mt-3">
          সরাসরি আমাদের শপে চলে আসুন
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-2">
          যেকোনো তথ্য, ভারী ফাইল পাঠানো বা বিশেষ পরামর্শের জন্য আমরা সবসময় প্রস্তুত
        </p>
      </div>

      {/* 3 Contact Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        
        {/* Address */}
        <div className="bg-white p-6 sm:p-7 rounded-3xl shadow-sm border border-slate-200/80 text-center flex flex-col items-center hover:border-blue-400 transition">
          <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center text-2xl mb-4 border border-rose-100">
            <MapPin className="w-7 h-7" />
          </div>
          <h4 className="font-bold text-[#031B4E] text-base">দোকানের স্থায়ী ঠিকানা</h4>
          <p className="text-xs text-slate-600 mt-2 leading-relaxed">
            {shopConfig.address}, {shopConfig.district}
          </p>
          <span className="text-[11px] text-[#0F4C81] font-semibold mt-3 bg-blue-50 px-3 py-1 rounded-full border border-blue-100">
            {shopConfig.openingHours}
          </span>
        </div>

        {/* Phone & WhatsApp */}
        <div className="bg-white p-6 sm:p-7 rounded-3xl shadow-sm border border-slate-200/80 text-center flex flex-col items-center hover:border-blue-400 transition">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-2xl mb-4 border border-emerald-100">
            <Phone className="w-7 h-7" />
          </div>
          <h4 className="font-bold text-[#031B4E] text-base">মোবাইল ও WhatsApp</h4>
          <p className="text-xs text-slate-600 mt-2 leading-relaxed">
            জরুরি প্রয়োজনে যেকোনো সময় সরাসরি কল অথবা মেসেজ করুন
          </p>
          <a 
            href={`tel:${shopConfig.phone}`} 
            className="text-base font-black text-emerald-600 mt-3 block hover:underline"
          >
            {shopConfig.phone}
          </a>
        </div>

        {/* Email & Digital Support */}
        <div className="bg-white p-6 sm:p-7 rounded-3xl shadow-sm border border-slate-200/80 text-center flex flex-col items-center hover:border-blue-400 transition">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-2xl mb-4 border border-blue-100">
            <Mail className="w-7 h-7" />
          </div>
          <h4 className="font-bold text-[#031B4E] text-base">ইমেইল সেবা ও ফাইল সেন্ডিং</h4>
          <p className="text-xs text-slate-600 mt-2 leading-relaxed">
            ভারী ফাইল, ড্রাইভ লিংক বা অফিশিয়াল ডকুমেন্ট পাঠাতে পারেন মেইলে
          </p>
          <a 
            href={`mailto:${shopConfig.email}`} 
            className="text-xs font-bold text-blue-700 mt-3 block hover:underline"
          >
            {shopConfig.email}
          </a>
        </div>

      </div>

      {/* Map guide & Quick Message Box */}
      <div className="bg-gradient-to-br from-[#031B4E] to-[#0F4C81] text-white rounded-3xl p-6 sm:p-10 shadow-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          <div className="lg:col-span-6 space-y-4">
            <span className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-300 bg-white/10 px-3 py-1 rounded-full border border-white/20">
              <Navigation className="w-3.5 h-3.5" />
              লোকেশন নির্দেশিকা
            </span>
            <h3 className="text-2xl sm:text-3xl font-black text-white">
              মরিচা বাজার, উখিয়া, কক্সবাজার
            </h3>
            <p className="text-xs sm:text-sm text-blue-100 leading-relaxed">
              মরিচা বাজারের প্রধান সড়কের সাথেই আমাদের কম্পিউটার ল্যাব ও প্রিন্টিং পয়েন্ট অবস্থিত। দূর-দূরান্তের গ্রাহকগণ ঘরে বসেই হোয়াটসঅ্যাপের মাধ্যমে ফাইল পাঠিয়ে কাজ করিয়ে নিতে পারেন।
            </p>

            <div className="space-y-2 pt-2 text-xs text-slate-200">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>বিকাশ ও নগদ পার্সোনাল নাম্বারে অনলাইন পেমেন্ট গ্রহণযোগ্য</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>উখিয়া, কোটবাজার ও মরিচা এলাকায় দ্রুত ডেলিভারি সমন্বয়</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>২৪ ঘণ্টা ডিজিটাল ফাইল ড্রপবক্স সচল</span>
              </div>
            </div>
          </div>

          {/* Quick Contact Form */}
          <div className="lg:col-span-6 bg-white text-slate-800 rounded-2xl p-6 shadow-2xl">
            <h4 className="font-black text-[#031B4E] text-base mb-1">
              সরাসরি কোনো প্রশ্ন আছে?
            </h4>
            <p className="text-xs text-slate-500 mb-4">
              নিচে আপনার বার্তাটি লিখে পাঠান, সঙ্গে সঙ্গে WhatsApp-এ কানেক্ট হবে
            </p>

            {sentSuccess && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-xl text-xs font-bold mb-3 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>ধন্যবাদ! বার্তাটি পাঠানো হয়েছে।</span>
              </div>
            )}

            <form onSubmit={handleInquirySubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  placeholder="আপনার নাম"
                  value={inquiryName}
                  onChange={(e) => setInquiryName(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                />
                <input
                  type="tel"
                  placeholder="মোবাইল নম্বর"
                  value={inquiryPhone}
                  onChange={(e) => setInquiryPhone(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <textarea
                rows={3}
                required
                placeholder="আপনি কোন সেবা সম্পর্কে জানতে চান..."
                value={inquiryMsg}
                onChange={(e) => setInquiryMsg(e.target.value)}
                className="w-full border border-slate-300 rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
              ></textarea>

              <button
                type="submit"
                className="w-full bg-[#031B4E] hover:bg-[#0F4C81] text-white font-bold py-2.5 rounded-xl transition flex items-center justify-center gap-2 shadow"
              >
                <Send className="w-4 h-4" />
                <span>মেসেজ পাঠান</span>
              </button>
            </form>
          </div>

        </div>
      </div>

    </section>
  );
};
