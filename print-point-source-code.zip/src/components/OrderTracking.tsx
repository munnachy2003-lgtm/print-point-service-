import React, { useState } from 'react';
import { 
  Search, 
  Package, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  MessageCircle, 
  ChevronRight,
  ShieldCheck,
  Calendar,
  CreditCard
} from 'lucide-react';
import { Order, ShopConfig } from '../types';

interface OrderTrackingProps {
  orders: Order[];
  shopConfig: ShopConfig;
}

export const OrderTracking: React.FC<OrderTrackingProps> = ({ orders, shopConfig }) => {
  const [trackInput, setTrackInput] = useState<string>('PP-1002');
  const [searchedOrder, setSearchedOrder] = useState<Order | null>(() => {
    return orders.find(o => o.id === 'PP-1002') || orders[0] || null;
  });
  const [hasSearched, setHasSearched] = useState<boolean>(true);

  const handleTrack = () => {
    const query = trackInput.trim().toUpperCase();
    if (!query) return;
    const found = orders.find(
      (o) => o.id.toUpperCase() === query || o.phone.includes(query)
    );
    setSearchedOrder(found || null);
    setHasSearched(true);
  };

  const getStatusStep = (status: Order['status']) => {
    switch (status) {
      case 'গৃহীত': return 1;
      case 'কাজ চলছে': return 2;
      case 'প্রস্তুত': return 3;
      case 'সম্পন্ন': return 4;
      default: return 1;
    }
  };

  const currentStep = searchedOrder ? getStatusStep(searchedOrder.status) : 0;

  return (
    <section id="order-track" className="max-w-7xl mx-auto px-4 sm:px-8 py-14 scroll-mt-16">
      <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-sm border border-slate-200">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Tracking Input Column */}
          <div className="lg:col-span-5 space-y-4">
            <span className="inline-flex items-center gap-1.5 text-[#0F4C81] font-bold text-xs uppercase bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
              <Package className="w-3.5 h-3.5 text-rose-600" />
              স্মার্ট রিয়েল-টাইম ট্র্যাকিং
            </span>

            <h3 className="text-2xl sm:text-3xl font-black text-[#031B4E]">
              আপনার কাজের বর্তমান অবস্থা জানুন
            </h3>

            <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
              অর্ডার করার পর প্রাপ্ত ট্র্যাকিং নম্বরটি (যেমন: <span className="font-mono font-bold text-slate-700">PP-1001</span>) অথবা আপনার মোবাইল নাম্বার দিয়ে কাজ কতটুকু এগিয়েছে তা দেখে নিন।
            </p>

            {/* Input Form */}
            <div className="flex gap-2 pt-2">
              <input
                type="text"
                value={trackInput}
                onChange={(e) => setTrackInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleTrack()}
                placeholder="অর্ডার নম্বর (যেমন: PP-1001)"
                className="w-full text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-600 font-semibold uppercase"
              />
              <button
                type="button"
                onClick={handleTrack}
                className="bg-[#031B4E] hover:bg-[#0F4C81] text-white text-xs sm:text-sm font-bold px-6 py-3 rounded-xl transition flex items-center gap-1.5 shrink-0 shadow-md active:scale-95"
              >
                <Search className="w-4 h-4" />
                <span>ট্র্যাক করুন</span>
              </button>
            </div>

            {/* Quick Demo Chips */}
            <div className="pt-2">
              <span className="text-[11px] text-slate-400 block mb-1 font-medium">দ্রুত দেখতে ক্লিক করুন:</span>
              <div className="flex flex-wrap gap-2">
                {orders.slice(0, 3).map((o) => (
                  <button
                    key={o.id}
                    onClick={() => {
                      setTrackInput(o.id);
                      setSearchedOrder(o);
                      setHasSearched(true);
                    }}
                    className="text-[11px] font-mono font-bold bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 px-2.5 py-1 rounded-lg border border-slate-200 transition"
                  >
                    {o.id} ({o.name.split(' ')[0]})
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Tracking Result Visualizer Column */}
          <div className="lg:col-span-7 bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-7">
            {searchedOrder ? (
              <div className="space-y-6">
                
                {/* Header of order */}
                <div className="flex flex-wrap justify-between items-center gap-2 border-b border-slate-200 pb-4">
                  <div>
                    <span className="text-xs text-slate-400 font-semibold block">অর্ডার আইডি</span>
                    <span className="font-mono text-lg font-black text-[#031B4E]">{searchedOrder.id}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`text-xs px-3 py-1 rounded-full font-bold flex items-center gap-1.5 ${
                      searchedOrder.status === 'সম্পন্ন'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : searchedOrder.status === 'প্রস্তুত'
                        ? 'bg-blue-100 text-blue-800 border border-blue-200'
                        : searchedOrder.status === 'কাজ চলছে'
                        ? 'bg-amber-100 text-amber-800 border border-amber-200'
                        : 'bg-slate-200 text-slate-700'
                    }`}>
                      <span className="w-2 h-2 rounded-full bg-current animate-ping"></span>
                      স্ট্যাটাস: {searchedOrder.status}
                    </span>
                  </div>
                </div>

                {/* 4-step Timeline */}
                <div className="py-2">
                  <div className="grid grid-cols-4 gap-2 relative">
                    {/* Connecting line */}
                    <div className="absolute top-4 left-6 right-6 h-1 bg-slate-200 -z-0">
                      <div 
                        className="h-full bg-emerald-500 transition-all duration-500" 
                        style={{ width: `${Math.min(100, ((currentStep - 1) / 3) * 100)}%` }}
                      ></div>
                    </div>

                    {[
                      { step: 1, label: 'গৃহীত' },
                      { step: 2, label: 'কাজ চলছে' },
                      { step: 3, label: 'প্রস্তুত' },
                      { step: 4, label: 'সম্পন্ন' }
                    ].map((s) => {
                      const isDone = currentStep >= s.step;
                      const isCurrent = currentStep === s.step;

                      return (
                        <div key={s.step} className="flex flex-col items-center text-center relative z-10">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all shadow-sm ${
                            isDone 
                              ? 'bg-emerald-500 text-white' 
                              : 'bg-white text-slate-400 border border-slate-300'
                          } ${isCurrent ? 'ring-4 ring-emerald-200 scale-110' : ''}`}>
                            {isDone ? <CheckCircle2 className="w-4 h-4" /> : s.step}
                          </div>
                          <span className={`text-[11px] mt-2 font-bold ${
                            isCurrent ? 'text-emerald-700' : isDone ? 'text-slate-700' : 'text-slate-400'
                          }`}>
                            {s.label}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Details Breakdown */}
                <div className="bg-white rounded-xl p-4 border border-slate-200 text-xs space-y-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <span className="text-slate-400 block">গ্রাহকের নাম:</span>
                      <span className="font-bold text-slate-800">{searchedOrder.name}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">সেবা:</span>
                      <span className="font-bold text-[#0F4C81]">{searchedOrder.service}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">পরিমাণ / নোট:</span>
                      <span className="font-bold text-slate-700">{searchedOrder.qty}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">আনুমানিক বিল ও পেমেন্ট:</span>
                      <span className="font-bold text-slate-800">
                        ৳{searchedOrder.estimatedPrice} ({searchedOrder.payment} - <span className={searchedOrder.paymentStatus === 'পরিশোধিত' ? 'text-emerald-600' : 'text-amber-600'}>{searchedOrder.paymentStatus}</span>)
                      </span>
                    </div>
                  </div>

                  {searchedOrder.notes && (
                    <div className="pt-2 border-t border-slate-100 text-slate-600 italic">
                      <span className="not-italic font-bold text-slate-700">বিশেষ নির্দেশনা:</span> {searchedOrder.notes}
                    </div>
                  )}
                </div>

                {/* Direct Action */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>অর্ডার তারিখ: {searchedOrder.date} ({searchedOrder.time})</span>
                  </div>

                  <a
                    href={`https://wa.me/${shopConfig.whatsapp}?text=${encodeURIComponent(
                      `আসসালামু আলাইকুম, আমি প্রিন্ট পয়েন্ট থেকে অর্ডার #${searchedOrder.id} (${searchedOrder.service}) এর আপডেট জানতে চাচ্ছি।`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition shadow-sm"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp-এ এই অর্ডার নিয়ে কথা বলুন</span>
                  </a>
                </div>

              </div>
            ) : hasSearched ? (
              <div className="text-center py-10 space-y-3">
                <AlertCircle className="w-12 h-12 text-rose-500 mx-auto" />
                <h4 className="font-bold text-slate-800 text-sm">
                  "{trackInput}" নম্বরের কোনো অর্ডার খুঁজে পাওয়া যায়নি!
                </h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  দয়া করে সঠিক ট্র্যাকিং আইডি লিখুন অথবা আপনার অর্ডার কনফার্ম করতে সরাসরি শপে বা WhatsApp-এ যোগাযোগ করুন।
                </p>
                <a
                  href={`https://wa.me/${shopConfig.whatsapp}?text=${encodeURIComponent(
                    `Hello Print Point, I want to check my order with ID: ${trackInput}`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 hover:underline pt-2"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp সহায়তায় যোগাযোগ করুন</span>
                </a>
              </div>
            ) : (
              <div className="text-center py-12 text-slate-400 text-xs">
                <Package className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                <p>আপনার অর্ডার নম্বর দিয়ে ট্র্যাক বাটনে ক্লিক করুন</p>
              </div>
            )}
          </div>

        </div>
      </div>
    </section>
  );
};
