import React from 'react';
import { 
  Printer, 
  IdCard, 
  Briefcase, 
  FileCheck, 
  Keyboard, 
  FileText, 
  Scan, 
  Palette, 
  FileSpreadsheet, 
  Landmark, 
  BookOpen, 
  Globe,
  Sparkles,
  ArrowRight,
  Monitor,
  Database,
  Image,
  Edit3,
  MousePointerClick
} from 'lucide-react';
import { ServiceItem } from '../types';

interface ServicesGridProps {
  services: ServiceItem[];
  onSelectService: (serviceName: string) => void;
  searchQuery: string;
  isOwnerMode?: boolean;
  onQuickUpdatePrice?: (serviceId: string, newPrice: number) => void;
}

export const ServicesGrid: React.FC<ServicesGridProps> = ({
  services,
  onSelectService,
  searchQuery,
  isOwnerMode,
  onQuickUpdatePrice
}) => {
  // Render illustration/icon box for each service
  const renderServiceIcon = (service: ServiceItem) => {
    switch (service.id) {
      case 'photo-edit':
        return (
          <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center text-xl shadow-inner border border-blue-200">
            <IdCard className="w-6 h-6" />
          </div>
        );
      case 'photo-retouch':
        return (
          <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-xl shadow-inner border border-emerald-200">
            <Sparkles className="w-6 h-6" />
          </div>
        );
      case 'job-apply':
        return (
          <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center text-xl shadow-inner border border-amber-200">
            <Briefcase className="w-6 h-6" />
          </div>
        );
      case 'gov-apply':
        return (
          <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center text-xl shadow-inner border border-indigo-200">
            <Landmark className="w-6 h-6" />
          </div>
        );
      case 'nid-birth':
        return (
          <div className="w-12 h-12 rounded-xl bg-cyan-100 text-cyan-700 flex items-center justify-center text-xl shadow-inner border border-cyan-200">
            <FileCheck className="w-6 h-6" />
          </div>
        );
      case 'graphics-logo':
        return (
          <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center text-xl shadow-inner border border-purple-200">
            <Palette className="w-6 h-6" />
          </div>
        );
      case 'banner-poster':
        return (
          <div className="w-12 h-12 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center text-xl shadow-inner border border-rose-200">
            <Image className="w-6 h-6" />
          </div>
        );
      case 'typing':
        return (
          <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center text-xl shadow-inner border border-slate-300">
            <Keyboard className="w-6 h-6" />
          </div>
        );
      case 'print-copy-scan':
        return (
          <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center text-xl shadow-inner border border-blue-200">
            <Printer className="w-6 h-6" />
          </div>
        );
      case 'pdf-edit-convert':
        return (
          <div className="w-12 h-12 rounded-xl bg-red-100 text-red-600 flex items-center justify-center text-xl shadow-inner border border-red-200">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
        );
      case 'data-entry':
        return (
          <div className="w-12 h-12 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center text-xl shadow-inner border border-teal-200">
            <Database className="w-6 h-6" />
          </div>
        );
      case 'custom-it':
        return (
          <div className="w-12 h-12 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center text-xl shadow-inner border border-sky-200">
            <Monitor className="w-6 h-6" />
          </div>
        );
      case 'cv-resume':
        return (
          <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center text-xl shadow-inner border border-amber-200">
            <FileText className="w-6 h-6" />
          </div>
        );
      case 'website-builder':
        return (
          <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-xl shadow-inner border border-emerald-200">
            <Globe className="w-6 h-6" />
          </div>
        );
      default:
        return (
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl shadow-inner border border-blue-200">
            <Printer className="w-6 h-6" />
          </div>
        );
    }
  };

  const filteredServices = services.filter((s) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      s.title.toLowerCase().includes(q) ||
      s.category.toLowerCase().includes(q) ||
      s.description.toLowerCase().includes(q)
    );
  });

  return (
    <section id="services" className="max-w-7xl mx-auto px-4 sm:px-8 py-10 scroll-mt-16">
      
      {/* Top Banner Tag matching mockup */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 bg-[#031B4E] text-white px-6 py-2 rounded-full font-black text-sm sm:text-base shadow-md border-2 border-amber-400">
          <Sparkles className="w-4 h-4 text-amber-400 fill-amber-400" />
          <span>আমাদের সকল সেবা সমূহ</span>
          <Sparkles className="w-4 h-4 text-amber-400 fill-amber-400" />
        </div>
        <p className="text-xs sm:text-sm text-slate-500 mt-2 font-medium">
          যেকোনো সেবায় ক্লিক করলেই তাৎক্ষণিক অর্ডার ফরম খুলে যাবে—খুব সহজেই ফাইল পাঠান ও কাজ বুঝে নিন
        </p>
      </div>

      {/* Grid of 14 Services + Big Red Order Card */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
        
        {filteredServices.map((service) => (
          <div
            key={service.id}
            onClick={() => onSelectService(service.title)}
            className="group bg-white rounded-2xl p-4 text-center shadow-sm hover:shadow-xl hover:-translate-y-1 transition duration-200 border border-slate-200/90 cursor-pointer flex flex-col justify-between relative overflow-hidden"
          >
            {service.popular && (
              <span className="absolute top-2 right-2 bg-rose-600 text-white text-[9px] font-black px-1.5 py-0.2 rounded-full">
                জনপ্রিয়
              </span>
            )}

            <div className="flex flex-col items-center">
              {/* Illustration / Icon Box */}
              <div className="mb-2.5 transition transform group-hover:scale-110 duration-200">
                {renderServiceIcon(service)}
              </div>

              {/* Title */}
              <h3 className="text-xs sm:text-sm font-bold text-slate-800 group-hover:text-rose-600 transition leading-tight line-clamp-2">
                {service.title}
              </h3>
            </div>

            <div className="pt-3 mt-2 border-t border-slate-100 flex flex-col gap-1 items-center">
              <span className="text-[11px] font-black text-[#031B4E] bg-blue-50/80 px-2 py-0.5 rounded-md border border-blue-100">
                ৳ {service.startingPrice} <span className="text-[10px] font-normal text-slate-500">{service.unit}</span>
              </span>

              {/* Owner mode inline price editor */}
              {isOwnerMode && onQuickUpdatePrice && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    const input = window.prompt(`"${service.title}" এর নতুন মূল্য কত দিতে চান (টাকা)?`, service.startingPrice.toString());
                    if (input && !isNaN(parseInt(input))) {
                      onQuickUpdatePrice(service.id, parseInt(input));
                    }
                  }}
                  className="mt-1 text-[10px] font-bold text-amber-800 bg-amber-100 hover:bg-amber-200 px-2 py-0.5 rounded border border-amber-300 flex items-center gap-1 transition"
                  title="দ্রুত মূল্য পরিবর্তন করুন"
                >
                  <Edit3 className="w-2.5 h-2.5" />
                  <span>দর পরিবর্তন</span>
                </button>
              )}
            </div>
          </div>
        ))}

        {/* 15. BIG RED CTA CARD (Exactly as in reference image!) */}
        <div 
          onClick={() => onSelectService('কাস্টম ডিজিটাল অর্ডার')}
          className="bg-gradient-to-br from-rose-600 to-red-700 text-white rounded-2xl p-4 text-center shadow-lg hover:shadow-2xl hover:scale-105 transition duration-200 border-2 border-rose-500 cursor-pointer flex flex-col justify-between items-center group"
        >
          <div className="flex flex-col items-center justify-center my-auto">
            <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center mb-2 shadow-inner group-hover:animate-bounce">
              <MousePointerClick className="w-6 h-6 text-amber-300" />
            </div>

            <h3 className="text-base sm:text-lg font-black leading-tight text-white">
              এখনই অর্ডার করুন
            </h3>
            <p className="text-[10px] text-red-100 font-medium mt-1">
              যেকোনো কাজের ফাইল পাঠান
            </p>
          </div>

          <button 
            type="button" 
            className="w-full bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs py-2 rounded-xl transition shadow flex items-center justify-center gap-1 mt-2"
          >
            <span>ক্লিক করুন</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>

    </section>
  );
};
