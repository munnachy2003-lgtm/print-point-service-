import React from 'react';
import { Order, ShopConfig } from '../types';

interface PrintableReceiptProps {
  order: Order | null;
  shopConfig: ShopConfig;
}

export const PrintableReceipt: React.FC<PrintableReceiptProps> = ({ order, shopConfig }) => {
  if (!order) return null;

  return (
    <div id="printable-receipt" className="hidden print:block p-8 bg-white text-black font-sans max-w-2xl mx-auto">
      {/* Header */}
      <div className="text-center border-b-2 border-black pb-4 mb-4">
        <h1 className="text-2xl font-black tracking-tight">{shopConfig.shopName}</h1>
        <p className="text-xs font-semibold text-gray-700">{shopConfig.tagline}</p>
        <p className="text-xs text-gray-600 mt-1">{shopConfig.address}, {shopConfig.district}</p>
        <p className="text-xs text-gray-600">মোবাইল: {shopConfig.phone} | WhatsApp: {shopConfig.whatsapp}</p>
        <div className="mt-2 inline-block px-3 py-0.5 bg-gray-200 text-black font-black text-xs uppercase tracking-widest border border-black">
          ক্যাশ মেমো / মানি রসিদ (INVOICE)
        </div>
      </div>

      {/* Invoice Details */}
      <div className="flex justify-between items-start text-xs mb-4">
        <div>
          <p><strong>গ্রাহকের নাম:</strong> {order.name}</p>
          <p><strong>মোবাইল নম্বর:</strong> {order.phone}</p>
          <p><strong>ডেলিভারি ধরন:</strong> {order.deliveryType}</p>
        </div>
        <div className="text-right">
          <p><strong>রসিদ নং:</strong> #{order.id}</p>
          <p><strong>তারিখ:</strong> {order.date}</p>
          <p><strong>সময়:</strong> {order.time}</p>
        </div>
      </div>

      {/* Item Table */}
      <table className="w-full text-xs border-collapse border border-black mb-4">
        <thead>
          <tr className="bg-gray-100">
            <th className="border border-black p-2 text-left">বিবরণ / সেবা</th>
            <th className="border border-black p-2 text-center">পরিমাণ</th>
            <th className="border border-black p-2 text-right">মূল্য (টাকা)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border border-black p-2">
              <div className="font-bold">{order.service}</div>
              {order.notes && <div className="text-[10px] text-gray-600 italic">নোট: {order.notes}</div>}
              {order.urgent && <div className="text-[10px] text-black font-semibold">তাৎক্ষণিক জরুরি সেবা অন্তর্ভুক্ত</div>}
            </td>
            <td className="border border-black p-2 text-center">{order.qty}</td>
            <td className="border border-black p-2 text-right font-bold">৳ {order.estimatedPrice}</td>
          </tr>
        </tbody>
        <tfoot>
          <tr className="font-bold">
            <td colSpan={2} className="border border-black p-2 text-right">সর্বমোট:</td>
            <td className="border border-black p-2 text-right">৳ {order.estimatedPrice}</td>
          </tr>
          <tr>
            <td colSpan={2} className="border border-black p-2 text-right font-semibold">পেমেন্ট মেথড ও স্ট্যাটাস:</td>
            <td className="border border-black p-2 text-right font-bold">{order.payment} ({order.paymentStatus})</td>
          </tr>
        </tfoot>
      </table>

      {/* Footer Notice & Signature */}
      <div className="pt-6 flex justify-between items-end text-xs">
        <div>
          <p className="font-bold">ধন্যবাদান্তে, প্রিন্ট পয়েন্ট</p>
          <p className="text-[10px] text-gray-600">কাজ ডেলিভারি নেওয়ার সময় রসিদ প্রদর্শন করুন।</p>
          <p className="text-[9px] text-gray-500 mt-1">সফটওয়্যার জেনারেটেড ডিজিটাল ইনভয়েস</p>
        </div>

        <div className="text-center">
          <div className="w-32 border-b border-black mb-1"></div>
          <p className="text-[11px] font-semibold">মালিক / কর্তৃপক্ষের স্বাক্ষর</p>
        </div>
      </div>
    </div>
  );
};
